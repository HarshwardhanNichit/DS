import java.io.*;
import java.time.LocalTime;

public class Berkeley {
    float diff(int h, int m, int s, int nh, int nm, int ns) {
        return (h - nh) * 3600 + (m - nm) * 60 + (s - ns);
    }

    float average(float[] diff, int n) {
        float sum = 0;
        for (float d : diff) sum += d;
        float avg = sum / n;
        System.out.println("Average time difference: " + avg);
        return avg;
    }

    void sync(float[] diff, int n, int h, int m, int s, int[] nh, int[] nm, int[] ns, float avg) {
        int[] syncTime = secondsToHMS((int) ((h * 3600 + m * 60 + s) + avg));
        System.out.println("\nSynchronized Clocks:");
        System.out.printf("Server ---> %02d:%02d:%02d\n", syncTime[0], syncTime[1], syncTime[2]);

        for (int i = 0; i < n; i++) {
            int[] t = secondsToHMS((int) ((nh[i] * 3600 + nm[i] * 60 + ns[i]) + avg));
            System.out.printf("Node %d ---> %02d:%02d:%02d\n", i + 1, t[0], t[1], t[2]);
        }
    }

    int[] secondsToHMS(int secs) {
        secs = (secs + 86400) % 86400; // Ensure time stays in 0–86399 seconds
        return new int[]{secs / 3600, (secs % 3600) / 60, secs % 60};
    }

    public static void main(String[] args) throws IOException {
        Berkeley b = new Berkeley();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Enter number of nodes: ");
        int n = Integer.parseInt(br.readLine());

        int[] nh = new int[n], nm = new int[n], ns = new int[n];
        LocalTime t = LocalTime.now();
        int h = t.getHour(), m = t.getMinute(), s = t.getSecond();

        for (int i = 0; i < n; i++) {
            System.out.println("Node " + (i + 1) + " Time:");
            System.out.print("Hour: "); nh[i] = Integer.parseInt(br.readLine());
            System.out.print("Minute: "); nm[i] = Integer.parseInt(br.readLine());
            System.out.print("Second: "); ns[i] = Integer.parseInt(br.readLine());
        }

        System.out.println("\nTime server time sent to all nodes: " + h + ":" + m + ":" + s);
        float[] diff = new float[n];
        for (int i = 0; i < n; i++) {
            diff[i] = b.diff(h, m, s, nh[i], nm[i], ns[i]);
            System.out.println("Node " + (i + 1) + " time diff: " + (int) diff[i]);
        }

        float avg = b.average(diff, n);
        b.sync(diff, n, h, m, s, nh, nm, ns, avg);
    }
}