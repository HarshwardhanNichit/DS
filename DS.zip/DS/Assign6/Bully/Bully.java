import java.util.Scanner;
public class Bully {
    static boolean[] state = new boolean[5];
    public static void up(int up) {
        if (state[up - 1]) {
            System.out.println("Process " + up + " is already up.");
        } else {
            state[up - 1] = true;
            System.out.println("Process " + up + " held election.");
            for (int i = up; i < 5; ++i) {
                System.out.println("Election message sent from process " + up + " to process " + (i + 1));
            }
            for (int i = up + 1; i <= 5; ++i) {
                if (state[i - 1]) {
                    System.out.println("Alive message sent from process " + i + " to process " + up);
                    break;
                }
            }
        }
    }
    public static void down(int down) {
        if (state[down - 1]) state[down - 1] = false;
        else System.out.println("Process " + down + " is already down.");
    }
    public static void mess(int mess) {
        if (state[mess - 1]) {
            if (state[4]) {
                System.out.println("OK");
            } else {
                System.out.println("Process " + mess + " election.");
                for (int i = mess; i < 5; ++i) {
                    System.out.println("Election message sent from process " + mess + " to process " + (i + 1));
                }
                for (int i = 5; i >= mess; --i) {
                    if (state[i - 1]) {
                        System.out.println("Coordinator message sent from process " + i + " to all.");
                        break;
                    }
                }
            }
        } else {
            System.out.println("Process " + mess + " is down.");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < 5; ++i) state[i] = true;

        System.out.println("5 active processes are: p1 p2 p3 p4 p5\nProcess 5 is the coordinator");

        int choice;
        do {
            System.out.println("1. Bring up a process\n2. Bring down a process\n3. Send a message\n4. Exit");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Bring up a process.");
                    int up = sc.nextInt();
                    if (up == 5) System.out.println("Process 5 is the coordinator.");
                    else up(up);
                    break;
                case 2:
                    System.out.println("Bring down a process.");
                    down(sc.nextInt());
                    break;
                case 3:
                    System.out.println("Which process will send a message?");
                    mess(sc.nextInt());
                    break;
                case 4:
                    System.out.println("Exiting the program...");
                    break;
                default:
                    System.out.println("Invalid choice, try again.");
            }
        } while (choice != 4);

        sc.close();
    }
}