import mpi.MPI;

public class ScatterGather {
    public static void main(String[] args) {
        MPI.Init(args);
        int rank = MPI.COMM_WORLD.Rank();
        int size = MPI.COMM_WORLD.Size();
        int root = 0;

        int[] sendbuf = null;
        if (rank == root) {
            sendbuf = new int[size];
            for (int i = 0; i < size; i++) sendbuf[i] = (i + 1) * 10;
            System.out.print("Original data: ");
            for (int val : sendbuf) System.out.print(val + " ");
            System.out.println();
        }

        int[] recvbuf = new int[1];
        MPI.COMM_WORLD.Scatter(sendbuf, 0, 1, MPI.INT, recvbuf, 0, 1, MPI.INT, root);

        System.out.println("Processor " + rank + " received: " + recvbuf[0]);
        recvbuf[0] *= 2;
        System.out.println("Processor " + rank + " after doubling: " + recvbuf[0]);

        if (rank == root) sendbuf = new int[size];
        MPI.COMM_WORLD.Gather(recvbuf, 0, 1, MPI.INT, sendbuf, 0, 1, MPI.INT, root);

        if (rank == root) {
            int totalSum = 0;
            System.out.print("Final gathered data: ");
            for (int val : sendbuf) {
                System.out.print(val + " ");
                totalSum += val;
            }
            System.out.println("\nTotal sum after processing = " + totalSum);
        }

        MPI.Finalize();
    }
}