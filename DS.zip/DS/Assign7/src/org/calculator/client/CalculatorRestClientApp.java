package org.calculator.client;

import java.io.*;
import java.net.*;

public class CalculatorRestClientApp {
    public static void main(String[] args) {
        try {
            String url = "http://localhost:8080/CalculatorWSApplication/webresources/calculator/add?a=10&b=5";
            HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
            con.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) response.append(inputLine);
            in.close();

            System.out.println("Response: " + response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}