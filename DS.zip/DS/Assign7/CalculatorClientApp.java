package org.calculator.client;

import org.calculator.CalculatorWS;
import org.calculator.CalculatorWSService;

public class CalculatorClientApp {
    public static void main(String[] args) {
        CalculatorWS calculator = new CalculatorWSService().getCalculatorWSPort();
        System.out.println("Addition Result: " + calculator.add(10, 5));
        System.out.println("Subtraction Result: " + calculator.subtract(10, 5));
    }
}