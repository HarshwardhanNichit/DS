import ReverseModule.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;
import java.io.*;

public class ReverseClient {
  public static void main(String[] args) {
    try {
      ORB orb = ORB.init(args, null);
      NamingContextExt ncRef = NamingContextExtHelper.narrow(
        orb.resolve_initial_references("NameService")
      );
      Reverse reverse = ReverseHelper.narrow(ncRef.resolve_str("Reverse"));

      System.out.print("Enter String = ");
      String input = new BufferedReader(new InputStreamReader(System.in)).readLine();
      System.out.println(reverse.reverse_string(input));
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}