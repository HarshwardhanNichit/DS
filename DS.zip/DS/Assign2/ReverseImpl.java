import ReverseModule.ReversePOA;

class ReverseImpl extends ReversePOA {
  public String reverse_string(String name) {
    return "Server Send " + new StringBuilder(name).reverse();
  }
}