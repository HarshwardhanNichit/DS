import ReverseModule.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;

public class ReverseServer {
  public static void main(String[] args) {
    try {
      ORB orb = ORB.init(args, null);
      POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
      rootPOA.the_POAManager().activate();

      ReverseImpl reverseImpl = new ReverseImpl();
      org.omg.CORBA.Object ref = rootPOA.servant_to_reference(reverseImpl);
      Reverse href = ReverseHelper.narrow(ref);

      NamingContextExt ncRef = NamingContextExtHelper.narrow(
        orb.resolve_initial_references("NameService")
      );
      ncRef.rebind(ncRef.to_name("Reverse"), href);

      System.out.println("Reverse Server ready...");
      orb.run();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}